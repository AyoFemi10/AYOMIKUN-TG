const config = require('../config/settings');

module.exports = {
    name: 'games',
    description: 'Interactive games menu',
    usage: '.games',
    
    async execute(message, whatsappService) {
        try {
            const chat = await message.getChat();
            const isGroup = chat.isGroup;
            
            const gamesText = `🎮 *${config.bot.name} - Games Menu*\n\n` +
                            `🎯 *Available Games:*\n\n` +
                            
                            `🎲 ${config.bot.commandPrefix}wcg - Word Chain Game\n` +
                            `   Challenge others with word connections!\n` +
                            `   Usage: ${config.bot.commandPrefix}wcg start/join/stop\n\n` +
                            
                            `⭕ ${config.bot.commandPrefix}tictactoe - Tic Tac Toe\n` +
                            `   Classic 3x3 grid game!\n` +
                            `   Usage: ${config.bot.commandPrefix}tictactoe @player\n\n` +
                            
                            `🎪 *Fun Commands:*\n` +
                            `🎯 ${config.bot.commandPrefix}dice - Roll dice (1-6)\n` +
                            `🪙 ${config.bot.commandPrefix}coinflip - Flip a coin\n` +
                            `🎰 ${config.bot.commandPrefix}slots - Slot machine\n` +
                            `🎲 ${config.bot.commandPrefix}random [min] [max] - Random number\n\n` +
                            
                            (isGroup ? 
                                `👥 *Group Games:*\n` +
                                `🔢 ${config.bot.commandPrefix}guess - Number guessing game\n` +
                                `❓ ${config.bot.commandPrefix}riddle - Random riddles\n` +
                                `🎭 ${config.bot.commandPrefix}truth - Truth or dare\n\n`
                            : '') +
                            
                            `🏆 *Game Rules:*\n` +
                            `• Most games work in both private and group chats\n` +
                            `• Some games require 2+ players\n` +
                            `• Type the game command to start playing\n` +
                            `• Have fun and play responsibly!\n\n` +
                            
                            `🎯 *Quick Start:*\n` +
                            `Try ${config.bot.commandPrefix}tictactoe @friend or ${config.bot.commandPrefix}wcg start`;

            await message.reply(gamesText);
            return { success: true };
            
        } catch (error) {
            console.error('Error in games command:', error);
            await message.reply('❌ Error loading games menu. Please try again.');
            return { success: false, error: error.message };
        }
    }
};