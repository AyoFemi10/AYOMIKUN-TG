const config = require('../config/settings');
const fs = require('fs');
const path = require('path');

// Simple word list for validation - in production, you'd want a larger dictionary
const VALID_WORDS = [
    'apple', 'elephant', 'tiger', 'rabbit', 'turtle', 'eagle', 'lion', 'octopus', 'snake', 'elephant',
    'dog', 'cat', 'bird', 'fish', 'horse', 'cow', 'pig', 'sheep', 'goat', 'duck',
    'bear', 'wolf', 'fox', 'deer', 'mouse', 'rat', 'bat', 'owl', 'hawk', 'crow',
    'ant', 'bee', 'butterfly', 'spider', 'frog', 'toad', 'lizard', 'snake', 'crocodile', 'alligator',
    'book', 'table', 'chair', 'house', 'tree', 'flower', 'water', 'fire', 'earth', 'air',
    'sun', 'moon', 'star', 'cloud', 'rain', 'snow', 'wind', 'storm', 'rainbow', 'ocean'
];

class WordChainGame {
    constructor() {
        this.games = new Map(); // chatId -> game data
        this.loadGames();
    }

    loadGames() {
        try {
            const filePath = path.join(__dirname, '../data/wcg-games.json');
            if (fs.existsSync(filePath)) {
                const data = fs.readFileSync(filePath, 'utf8');
                const gamesData = JSON.parse(data);
                this.games = new Map(Object.entries(gamesData));
            }
        } catch (error) {
            console.error('Error loading WCG games:', error);
        }
    }

    saveGames() {
        try {
            const filePath = path.join(__dirname, '../data/wcg-games.json');
            const dir = path.dirname(filePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            const gamesData = Object.fromEntries(this.games);
            fs.writeFileSync(filePath, JSON.stringify(gamesData, null, 2));
        } catch (error) {
            console.error('Error saving WCG games:', error);
        }
    }

    startGame(chatId, hostId, hostName) {
        const game = {
            chatId,
            hostId,
            hostName,
            players: [{ id: hostId, name: hostName, score: 0 }],
            currentPlayerIndex: 0,
            words: [],
            lastWord: null,
            status: 'waiting', // waiting, active, finished
            createdAt: new Date().toISOString(),
            round: 1,
            maxRounds: 10
        };
        
        this.games.set(chatId, game);
        this.saveGames();
        return game;
    }

    joinGame(chatId, playerId, playerName) {
        const game = this.games.get(chatId);
        if (!game || game.status !== 'waiting') {
            return null;
        }

        // Check if player already joined
        if (game.players.find(p => p.id === playerId)) {
            return { error: 'already_joined' };
        }

        game.players.push({ id: playerId, name: playerName, score: 0 });
        this.saveGames();
        return game;
    }

    startRound(chatId) {
        const game = this.games.get(chatId);
        if (!game || game.players.length < 2) {
            return null;
        }

        game.status = 'active';
        game.currentPlayerIndex = 0;
        game.words = [];
        game.lastWord = null;
        this.saveGames();
        return game;
    }

    isValidWord(word) {
        return VALID_WORDS.includes(word.toLowerCase());
    }

    canPlayWord(game, word) {
        const cleanWord = word.toLowerCase().trim();
        
        // Check if word is valid
        if (!this.isValidWord(cleanWord)) {
            return { valid: false, reason: 'invalid_word' };
        }

        // Check if word was already used
        if (game.words.includes(cleanWord)) {
            return { valid: false, reason: 'already_used' };
        }

        // Check if word starts with last letter of previous word
        if (game.lastWord) {
            const lastLetter = game.lastWord.slice(-1);
            if (cleanWord[0] !== lastLetter) {
                return { valid: false, reason: 'wrong_letter', expectedLetter: lastLetter };
            }
        }

        return { valid: true };
    }

    playWord(chatId, playerId, word) {
        const game = this.games.get(chatId);
        if (!game || game.status !== 'active') {
            return { error: 'no_active_game' };
        }

        const currentPlayer = game.players[game.currentPlayerIndex];
        if (currentPlayer.id !== playerId) {
            return { error: 'not_your_turn', currentPlayer: currentPlayer.name };
        }

        const validation = this.canPlayWord(game, word);
        if (!validation.valid) {
            return { error: validation.reason, expectedLetter: validation.expectedLetter };
        }

        const cleanWord = word.toLowerCase().trim();
        
        // Add word to game
        game.words.push(cleanWord);
        game.lastWord = cleanWord;
        currentPlayer.score += cleanWord.length; // Score based on word length

        // Move to next player
        game.currentPlayerIndex = (game.currentPlayerIndex + 1) % game.players.length;

        // Check if round is complete
        if (game.words.length >= game.maxRounds) {
            game.status = 'finished';
            game.winner = this.getWinner(game);
        }

        this.saveGames();
        return { success: true, game, word: cleanWord };
    }

    getWinner(game) {
        return game.players.reduce((winner, player) => 
            player.score > winner.score ? player : winner
        );
    }

    skipTurn(chatId, playerId) {
        const game = this.games.get(chatId);
        if (!game || game.status !== 'active') {
            return null;
        }

        const currentPlayer = game.players[game.currentPlayerIndex];
        if (currentPlayer.id !== playerId) {
            return { error: 'not_your_turn' };
        }

        // Move to next player
        game.currentPlayerIndex = (game.currentPlayerIndex + 1) % game.players.length;
        this.saveGames();
        return { success: true, game };
    }

    endGame(chatId, playerId) {
        const game = this.games.get(chatId);
        if (!game) {
            return null;
        }

        // Only host or current player can end game
        if (game.hostId !== playerId && game.players[game.currentPlayerIndex]?.id !== playerId) {
            return { error: 'no_permission' };
        }

        this.games.delete(chatId);
        this.saveGames();
        return { success: true, game };
    }

    getGame(chatId) {
        return this.games.get(chatId);
    }

    getGameStats(chatId) {
        const game = this.games.get(chatId);
        if (!game) return null;

        return {
            totalWords: game.words.length,
            players: game.players.map(p => ({ name: p.name, score: p.score })),
            currentRound: game.words.length + 1,
            maxRounds: game.maxRounds,
            lastWord: game.lastWord,
            status: game.status
        };
    }
}

const wordChainGame = new WordChainGame();

module.exports = {
    name: 'wcg',
    description: 'Word Chain Game - Connect words by their last and first letters',
    usage: '.wcg [start/join/play/skip/stop/stats] [word]',
    
    async execute(message, whatsappService, args) {
        try {
            const chat = await message.getChat();
            const chatId = chat.id._serialized;
            const senderId = message.from;
            const senderNumber = senderId.split('@')[0];
            
            // Get sender contact info
            const senderContact = await message.getContact();
            const senderName = senderContact.pushname || senderContact.name || senderNumber;

            if (args.length === 0) {
                const helpText = `🎲 *Word Chain Game (WCG)*\n\n` +
                               `*How to Play:*\n` +
                               `Players take turns saying words that start with the last letter of the previous word.\n\n` +
                               `*Commands:*\n` +
                               `${config.bot.commandPrefix}wcg start - Start a new game\n` +
                               `${config.bot.commandPrefix}wcg join - Join an existing game\n` +
                               `${config.bot.commandPrefix}wcg play [word] - Play a word\n` +
                               `${config.bot.commandPrefix}wcg skip - Skip your turn\n` +
                               `${config.bot.commandPrefix}wcg stop - End the game\n` +
                               `${config.bot.commandPrefix}wcg stats - Show game statistics\n\n` +
                               `*Example:*\n` +
                               `Player 1: "apple" → Player 2: "elephant" → Player 1: "tiger"\n\n` +
                               `*Rules:*\n` +
                               `• Words must be valid English words\n` +
                               `• No repeating words in the same game\n` +
                               `• Score = total letters of your words\n` +
                               `• Game ends after ${wordChainGame.maxRounds || 10} words`;

                await message.reply(helpText);
                return { success: true };
            }

            const action = args[0].toLowerCase();

            switch (action) {
                case 'start':
                    const existingGame = wordChainGame.getGame(chatId);
                    if (existingGame && existingGame.status !== 'finished') {
                        await message.reply(`🎲 A Word Chain Game is already active!\n\nCurrent players: ${existingGame.players.map(p => p.name).join(', ')}\n\nUse \`${config.bot.commandPrefix}wcg join\` to join or \`${config.bot.commandPrefix}wcg stop\` to end it.`);
                        return { success: false };
                    }

                    const newGame = wordChainGame.startGame(chatId, senderId, senderName);
                    
                    await message.reply(`🎲 *Word Chain Game Started!*\n\n` +
                                      `🎯 Host: ${senderName}\n` +
                                      `👥 Players: 1/∞\n` +
                                      `📝 Rounds: ${newGame.maxRounds}\n\n` +
                                      `Waiting for more players...\n` +
                                      `Type \`${config.bot.commandPrefix}wcg join\` to join!\n\n` +
                                      `Need at least 2 players to start playing.`);
                    break;

                case 'join':
                    const gameToJoin = wordChainGame.getGame(chatId);
                    if (!gameToJoin) {
                        await message.reply(`❌ No active Word Chain Game found.\n\nStart one with \`${config.bot.commandPrefix}wcg start\``);
                        return { success: false };
                    }

                    if (gameToJoin.status !== 'waiting') {
                        await message.reply('❌ Cannot join - game is already in progress!');
                        return { success: false };
                    }

                    const joinResult = wordChainGame.joinGame(chatId, senderId, senderName);
                    if (!joinResult) {
                        await message.reply('❌ Failed to join the game.');
                        return { success: false };
                    }

                    if (joinResult.error === 'already_joined') {
                        await message.reply('❌ You are already in this game!');
                        return { success: false };
                    }

                    await message.reply(`✅ ${senderName} joined the game!\n\n` +
                                      `👥 Players (${joinResult.players.length}): ${joinResult.players.map(p => p.name).join(', ')}\n\n` +
                                      `Ready to start? Host can use \`${config.bot.commandPrefix}wcg play [word]\` to begin!`);

                    // Auto-start if we have 2+ players
                    if (joinResult.players.length >= 2) {
                        wordChainGame.startRound(chatId);
                        const startedGame = wordChainGame.getGame(chatId);
                        const currentPlayer = startedGame.players[startedGame.currentPlayerIndex];
                        
                        await message.reply(`🎯 *Game Started!*\n\n` +
                                          `👤 Current turn: ${currentPlayer.name}\n` +
                                          `📝 Say any word to begin!\n\n` +
                                          `Use: \`${config.bot.commandPrefix}wcg play [word]\``);
                    }
                    break;

                case 'play':
                    if (args.length < 2) {
                        await message.reply(`❌ Please provide a word to play.\n\nUsage: \`${config.bot.commandPrefix}wcg play [word]\``);
                        return { success: false };
                    }

                    const word = args[1];
                    const playResult = wordChainGame.playWord(chatId, senderId, word);

                    if (playResult.error) {
                        let errorMsg = '';
                        switch (playResult.error) {
                            case 'no_active_game':
                                errorMsg = `❌ No active game found.\n\nStart one with \`${config.bot.commandPrefix}wcg start\``;
                                break;
                            case 'not_your_turn':
                                errorMsg = `❌ It's not your turn!\n\nCurrent player: ${playResult.currentPlayer}`;
                                break;
                            case 'invalid_word':
                                errorMsg = `❌ "${word}" is not a valid word. Try another one!`;
                                break;
                            case 'already_used':
                                errorMsg = `❌ "${word}" was already used. Choose a different word!`;
                                break;
                            case 'wrong_letter':
                                errorMsg = `❌ "${word}" must start with "${playResult.expectedLetter.toUpperCase()}"`;
                                break;
                        }
                        await message.reply(errorMsg);
                        return { success: false };
                    }

                    const game = playResult.game;
                    const nextPlayer = game.players[game.currentPlayerIndex];
                    
                    if (game.status === 'finished') {
                        const winner = game.winner;
                        const finalScores = game.players
                            .sort((a, b) => b.score - a.score)
                            .map((p, i) => `${i + 1}. ${p.name}: ${p.score} points`)
                            .join('\n');

                        await message.reply(`🎉 *Game Finished!*\n\n` +
                                          `🏆 Winner: ${winner.name} (${winner.score} points)\n\n` +
                                          `📊 Final Scores:\n${finalScores}\n\n` +
                                          `🎲 Total words: ${game.words.length}\n` +
                                          `📝 Word chain: ${game.words.join(' → ')}\n\n` +
                                          `Thanks for playing! Start a new game with \`${config.bot.commandPrefix}wcg start\``);
                    } else {
                        const lastLetter = playResult.word.slice(-1).toUpperCase();
                        
                        await message.reply(`✅ *${senderName}* played: **${playResult.word}**\n\n` +
                                          `🎯 Next turn: ${nextPlayer.name}\n` +
                                          `📝 Next word must start with: **${lastLetter}**\n` +
                                          `🔢 Round: ${game.words.length}/${game.maxRounds}\n\n` +
                                          `💡 ${nextPlayer.name}, use: \`${config.bot.commandPrefix}wcg play [word starting with ${lastLetter}]\``);
                    }
                    break;

                case 'skip':
                    const skipResult = wordChainGame.skipTurn(chatId, senderId);
                    if (!skipResult) {
                        await message.reply(`❌ No active game found.`);
                        return { success: false };
                    }

                    if (skipResult.error === 'not_your_turn') {
                        await message.reply('❌ It\'s not your turn to skip!');
                        return { success: false };
                    }

                    const skippedGame = skipResult.game;
                    const newCurrentPlayer = skippedGame.players[skippedGame.currentPlayerIndex];
                    
                    await message.reply(`⏭️ ${senderName} skipped their turn.\n\n` +
                                      `🎯 Current turn: ${newCurrentPlayer.name}\n` +
                                      `📝 Last word: ${skippedGame.lastWord || 'None'}\n\n` +
                                      `${newCurrentPlayer.name}, your turn!`);
                    break;

                case 'stop':
                case 'end':
                    const endResult = wordChainGame.endGame(chatId, senderId);
                    if (!endResult) {
                        await message.reply('❌ No active game found.');
                        return { success: false };
                    }

                    if (endResult.error === 'no_permission') {
                        await message.reply('❌ Only the game host or current player can end the game.');
                        return { success: false };
                    }

                    const endedGame = endResult.game;
                    await message.reply(`🛑 *Game Ended by ${senderName}*\n\n` +
                                      `📊 Final Stats:\n` +
                                      `• Total words played: ${endedGame.words.length}\n` +
                                      `• Players: ${endedGame.players.map(p => `${p.name} (${p.score})`).join(', ')}\n\n` +
                                      `Thanks for playing!`);
                    break;

                case 'stats':
                    const stats = wordChainGame.getGameStats(chatId);
                    if (!stats) {
                        await message.reply('❌ No active game found.');
                        return { success: false };
                    }

                    const statsText = `📊 *Word Chain Game Stats*\n\n` +
                                    `🎯 Status: ${stats.status}\n` +
                                    `🔢 Round: ${stats.currentRound}/${stats.maxRounds}\n` +
                                    `📝 Total words: ${stats.totalWords}\n` +
                                    `🎲 Last word: ${stats.lastWord || 'None'}\n\n` +
                                    `👥 *Players & Scores:*\n` +
                                    stats.players.map(p => `• ${p.name}: ${p.score} points`).join('\n');

                    await message.reply(statsText);
                    break;

                default:
                    await message.reply(`❌ Unknown action: ${action}\n\nUse \`${config.bot.commandPrefix}wcg\` to see available commands.`);
                    return { success: false };
            }

            return { success: true };
            
        } catch (error) {
            console.error('Error in wcg command:', error);
            await message.reply('❌ Error in Word Chain Game. Please try again.');
            return { success: false, error: error.message };
        }
    }
};