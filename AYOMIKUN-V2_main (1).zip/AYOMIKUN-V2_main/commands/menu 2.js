const config = require('../config/settings');

module.exports = {
    name: 'menu',
    description: 'Display bot menu and available commands',
    usage: '.menu',
    
    async execute(message, whatsappService) {
        try {
            const chat = await message.getChat();
            const isGroup = chat.isGroup;
            
            const menuText = `🤖 *${config.bot.name}*\n` +
                           `Version: ${config.bot.version}\n` +
                           `Developer: ${config.bot.developer}\n\n` +
                           
                           `📋 *Core Commands:*\n` +
                           `🏓 ${config.bot.commandPrefix}ping - Check bot responsiveness\n` +
                           `📜 ${config.bot.commandPrefix}menu - Display this menu\n` +
                           (isGroup ? `👥 ${config.bot.commandPrefix}tagall [message] - Tag all members\n` : '') +
                           `💳 ${config.bot.commandPrefix}payment [amount] - Process payment\n` +
                           `💰 ${config.bot.commandPrefix}pay [amount] - Alternative payment\n` +
                           `🌐 ${config.bot.commandPrefix}webpair - Get web pairing URL\n\n` +
                           
                           `🎉 *Entertainment:*\n` +
                           `😂 ${config.bot.commandPrefix}jokes - Random funny jokes\n` +
                           `🎪 ${config.bot.commandPrefix}fun - Fun activities & challenges\n` +
                           `😎 ${config.bot.commandPrefix}rizz - Smooth pickup lines\n` +
                           `💭 ${config.bot.commandPrefix}quotes - Inspirational quotes\n` +
                           `📖 ${config.bot.commandPrefix}bible - Bible verses\n` +
                           `📖 ${config.bot.commandPrefix}quran - Quran verses\n\n` +
                           
                           `🛡️ *Admin Commands (Owner Only):*\n` +
                           `🚫 ${config.bot.commandPrefix}block [number] - Block contact\n` +
                           `✅ ${config.bot.commandPrefix}unblock [number] - Unblock contact\n` +
                           `🚫 ${config.bot.commandPrefix}bangroup - Ban current group\n` +
                           `✅ ${config.bot.commandPrefix}unbangroup [id] - Unban group\n` +
                           `🚫 ${config.bot.commandPrefix}banwhatsapp [number] - Global ban\n` +
                           `✅ ${config.bot.commandPrefix}unbanwhatsapp [number] - Global unban\n\n` +
                           
                           `⚡ *Advanced Features:*\n` +
                           `👁️ ${config.bot.commandPrefix}viewonce - View once media capture\n` +
                           `📞 ${config.bot.commandPrefix}call [number] - Call someone\n` +
                           `👥 ${config.bot.commandPrefix}kick @user - Remove from group\n` +
                           `➕ ${config.bot.commandPrefix}add [number] - Add to group\n` +
                           `👑 ${config.bot.commandPrefix}promote @user - Make admin\n` +
                           `💥 ${config.bot.commandPrefix}spampair [number] - Spam pair (Admin)\n` +
                           `🐛 ${config.bot.commandPrefix}groupbug - Group bug attack (Admin)\n` +
                           `🔐 ${config.bot.commandPrefix}session - Session ID manager (Admin)\n\n` +
                           
                           `🎮 *Gaming Features:*\n` +
                           `🎯 ${config.bot.commandPrefix}games - Gaming menu & features\n` +
                           `🔗 ${config.bot.commandPrefix}wcg - Word Chain Game\n` +
                           `⭕ ${config.bot.commandPrefix}tictactoe - Tic-tac-toe game\n\n` +
                           
                           `⚙️ *System Commands:*\n` +
                           `💻 ${config.bot.commandPrefix}runtime - Bot performance stats\n\n` +
                           
                           `📱 *Bot Information:*\n` +
                           `• Prefix: ${config.bot.commandPrefix}\n` +
                           `• Payment: ${config.payment.minAmount}-${config.payment.maxAmount} ${config.payment.currency}\n` +
                           `• Total Commands: 30\n` +
                           `• Web Pairing: Available\n` +
                           `• Gaming: Word Chain & Tic-tac-toe\n\n` +
                           
                           `💡 *Tips:* Commands are case-sensitive. Use responsibly!`;
            
            await message.reply(menuText);
            
            return { success: true };
            
        } catch (error) {
            console.error('Error in menu command:', error);
            await message.reply('❌ Error displaying menu.');
            return { success: false, error: error.message };
        }
    }
};
