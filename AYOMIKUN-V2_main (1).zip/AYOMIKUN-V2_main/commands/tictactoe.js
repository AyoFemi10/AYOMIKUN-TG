const config = require('../config/settings');
const fs = require('fs');
const path = require('path');

class TicTacToeGame {
    constructor() {
        this.games = new Map(); // chatId -> game data
        this.loadGames();
    }

    loadGames() {
        try {
            const filePath = path.join(__dirname, '../data/tictactoe-games.json');
            if (fs.existsSync(filePath)) {
                const data = fs.readFileSync(filePath, 'utf8');
                const gamesData = JSON.parse(data);
                this.games = new Map(Object.entries(gamesData));
            }
        } catch (error) {
            console.error('Error loading Tic-tac-toe games:', error);
        }
    }

    saveGames() {
        try {
            const filePath = path.join(__dirname, '../data/tictactoe-games.json');
            const dir = path.dirname(filePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }
            const gamesData = Object.fromEntries(this.games);
            fs.writeFileSync(filePath, JSON.stringify(gamesData, null, 2));
        } catch (error) {
            console.error('Error saving Tic-tac-toe games:', error);
        }
    }

    createGame(chatId, player1Id, player1Name, player2Id, player2Name) {
        const game = {
            chatId,
            player1: { id: player1Id, name: player1Name, symbol: '❌' },
            player2: { id: player2Id, name: player2Name, symbol: '⭕' },
            board: Array(9).fill('⬜'),
            currentPlayer: 1, // 1 or 2
            status: 'active', // active, finished, draw
            winner: null,
            moves: 0,
            createdAt: new Date().toISOString()
        };

        this.games.set(chatId, game);
        this.saveGames();
        return game;
    }

    getGame(chatId) {
        return this.games.get(chatId);
    }

    makeMove(chatId, playerId, position) {
        const game = this.games.get(chatId);
        if (!game || game.status !== 'active') {
            return { error: 'no_active_game' };
        }

        // Check if it's the player's turn
        const currentPlayerObj = game.currentPlayer === 1 ? game.player1 : game.player2;
        if (currentPlayerObj.id !== playerId) {
            return { error: 'not_your_turn', currentPlayer: currentPlayerObj.name };
        }

        // Validate position (1-9)
        if (position < 1 || position > 9) {
            return { error: 'invalid_position' };
        }

        const boardIndex = position - 1;
        
        // Check if position is already taken
        if (game.board[boardIndex] !== '⬜') {
            return { error: 'position_taken' };
        }

        // Make the move
        game.board[boardIndex] = currentPlayerObj.symbol;
        game.moves++;

        // Check for winner
        const winner = this.checkWinner(game.board);
        if (winner) {
            game.status = 'finished';
            game.winner = winner === '❌' ? game.player1 : game.player2;
        } else if (game.moves === 9) {
            game.status = 'draw';
        } else {
            // Switch players
            game.currentPlayer = game.currentPlayer === 1 ? 2 : 1;
        }

        this.saveGames();
        return { success: true, game };
    }

    checkWinner(board) {
        const winPatterns = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
            [0, 4, 8], [2, 4, 6] // Diagonals
        ];

        for (const pattern of winPatterns) {
            const [a, b, c] = pattern;
            if (board[a] !== '⬜' && board[a] === board[b] && board[b] === board[c]) {
                return board[a];
            }
        }

        return null;
    }

    formatBoard(board) {
        const positions = board.map((cell, index) => 
            cell === '⬜' ? `${index + 1}️⃣` : cell
        );

        return `${positions[0]} ${positions[1]} ${positions[2]}\n` +
               `${positions[3]} ${positions[4]} ${positions[5]}\n` +
               `${positions[6]} ${positions[7]} ${positions[8]}`;
    }

    endGame(chatId) {
        this.games.delete(chatId);
        this.saveGames();
    }
}

const ticTacToeGame = new TicTacToeGame();

module.exports = {
    name: 'tictactoe',
    description: 'Play Tic-tac-toe with another player',
    usage: '.tictactoe @player or .tictactoe [move] [position]',
    
    async execute(message, whatsappService, args) {
        try {
            const chat = await message.getChat();
            const chatId = chat.id._serialized;
            const senderId = message.from;
            const senderNumber = senderId.split('@')[0];
            
            // Get sender contact info
            const senderContact = await message.getContact();
            const senderName = senderContact.pushname || senderContact.name || senderNumber;

            if (args.length === 0) {
                const helpText = `⭕ *Tic-Tac-Toe Game*\n\n` +
                               `*How to Play:*\n` +
                               `Get 3 in a row (horizontal, vertical, or diagonal) to win!\n\n` +
                               `*Commands:*\n` +
                               `${config.bot.commandPrefix}tictactoe @player - Challenge someone\n` +
                               `${config.bot.commandPrefix}tictactoe move [1-9] - Make a move\n` +
                               `${config.bot.commandPrefix}tictactoe board - Show current board\n` +
                               `${config.bot.commandPrefix}tictactoe end - End current game\n\n` +
                               `*Board Positions:*\n` +
                               `1️⃣ 2️⃣ 3️⃣\n` +
                               `4️⃣ 5️⃣ 6️⃣\n` +
                               `7️⃣ 8️⃣ 9️⃣\n\n` +
                               `*Example:*\n` +
                               `${config.bot.commandPrefix}tictactoe move 5 - Place your symbol in center`;

                await message.reply(helpText);
                return { success: true };
            }

            const action = args[0].toLowerCase();

            // Handle mentions (starting a new game)
            if (message.mentionedIds && message.mentionedIds.length > 0) {
                const existingGame = ticTacToeGame.getGame(chatId);
                if (existingGame && existingGame.status === 'active') {
                    await message.reply(`⭕ A Tic-tac-toe game is already active!\n\n` +
                                      `Players: ${existingGame.player1.name} vs ${existingGame.player2.name}\n\n` +
                                      `Use \`${config.bot.commandPrefix}tictactoe end\` to end it first.`);
                    return { success: false };
                }

                const opponentId = message.mentionedIds[0];
                const opponentNumber = opponentId.split('@')[0];
                
                // Can't play against yourself
                if (opponentId === senderId) {
                    await message.reply('❌ You cannot play against yourself!');
                    return { success: false };
                }

                // Get opponent contact info
                const opponentContact = await whatsappService.getContactById(opponentId);
                const opponentName = opponentContact ? 
                    (opponentContact.pushname || opponentContact.name || opponentNumber) : 
                    opponentNumber;

                const newGame = ticTacToeGame.createGame(chatId, senderId, senderName, opponentId, opponentName);
                
                const boardDisplay = ticTacToeGame.formatBoard(newGame.board);
                
                await message.reply(`⭕ *Tic-Tac-Toe Game Started!*\n\n` +
                                  `${newGame.player1.symbol} Player 1: ${newGame.player1.name}\n` +
                                  `${newGame.player2.symbol} Player 2: ${newGame.player2.name}\n\n` +
                                  `${boardDisplay}\n\n` +
                                  `🎯 ${newGame.player1.name}'s turn (${newGame.player1.symbol})\n\n` +
                                  `Use: \`${config.bot.commandPrefix}tictactoe move [1-9]\` to play`);
                return { success: true };
            }

            switch (action) {
                case 'move':
                    if (args.length < 2) {
                        await message.reply(`❌ Please specify a position (1-9).\n\nUsage: \`${config.bot.commandPrefix}tictactoe move [1-9]\``);
                        return { success: false };
                    }

                    const position = parseInt(args[1]);
                    if (isNaN(position)) {
                        await message.reply('❌ Position must be a number between 1 and 9.');
                        return { success: false };
                    }

                    const moveResult = ticTacToeGame.makeMove(chatId, senderId, position);
                    
                    if (moveResult.error) {
                        let errorMsg = '';
                        switch (moveResult.error) {
                            case 'no_active_game':
                                errorMsg = `❌ No active game found.\n\nStart one with \`${config.bot.commandPrefix}tictactoe @player\``;
                                break;
                            case 'not_your_turn':
                                errorMsg = `❌ It's not your turn!\n\nCurrent player: ${moveResult.currentPlayer}`;
                                break;
                            case 'invalid_position':
                                errorMsg = '❌ Invalid position. Choose a number between 1 and 9.';
                                break;
                            case 'position_taken':
                                errorMsg = '❌ That position is already taken. Choose another one!';
                                break;
                        }
                        await message.reply(errorMsg);
                        return { success: false };
                    }

                    const game = moveResult.game;
                    const boardDisplay = ticTacToeGame.formatBoard(game.board);
                    
                    if (game.status === 'finished') {
                        await message.reply(`🎉 *Game Over!*\n\n` +
                                          `${boardDisplay}\n\n` +
                                          `🏆 Winner: ${game.winner.name} (${game.winner.symbol})\n\n` +
                                          `Thanks for playing! Start a new game with \`${config.bot.commandPrefix}tictactoe @player\``);
                        ticTacToeGame.endGame(chatId);
                    } else if (game.status === 'draw') {
                        await message.reply(`🤝 *It's a Draw!*\n\n` +
                                          `${boardDisplay}\n\n` +
                                          `Great game! Start a new one with \`${config.bot.commandPrefix}tictactoe @player\``);
                        ticTacToeGame.endGame(chatId);
                    } else {
                        const currentPlayerObj = game.currentPlayer === 1 ? game.player1 : game.player2;
                        
                        await message.reply(`✅ *Move played!*\n\n` +
                                          `${boardDisplay}\n\n` +
                                          `🎯 ${currentPlayerObj.name}'s turn (${currentPlayerObj.symbol})\n\n` +
                                          `Use: \`${config.bot.commandPrefix}tictactoe move [1-9]\``);
                    }
                    break;

                case 'board':
                case 'show':
                    const currentGame = ticTacToeGame.getGame(chatId);
                    if (!currentGame) {
                        await message.reply(`❌ No active game found.\n\nStart one with \`${config.bot.commandPrefix}tictactoe @player\``);
                        return { success: false };
                    }

                    const currentBoard = ticTacToeGame.formatBoard(currentGame.board);
                    const currentPlayerObj = currentGame.currentPlayer === 1 ? currentGame.player1 : currentGame.player2;
                    
                    await message.reply(`⭕ *Current Game*\n\n` +
                                      `${currentGame.player1.symbol} ${currentGame.player1.name} vs ${currentGame.player2.name} ${currentGame.player2.symbol}\n\n` +
                                      `${currentBoard}\n\n` +
                                      `🎯 Current turn: ${currentPlayerObj.name} (${currentPlayerObj.symbol})\n` +
                                      `📊 Moves played: ${currentGame.moves}/9`);
                    break;

                case 'end':
                case 'stop':
                    const gameToEnd = ticTacToeGame.getGame(chatId);
                    if (!gameToEnd) {
                        await message.reply('❌ No active game found.');
                        return { success: false };
                    }

                    // Only players in the game can end it
                    if (gameToEnd.player1.id !== senderId && gameToEnd.player2.id !== senderId) {
                        await message.reply('❌ Only players in the game can end it.');
                        return { success: false };
                    }

                    ticTacToeGame.endGame(chatId);
                    await message.reply(`🛑 *Game ended by ${senderName}*\n\n` +
                                      `Thanks for playing! Start a new game anytime with \`${config.bot.commandPrefix}tictactoe @player\``);
                    break;

                default:
                    // Check if it's a direct position move (for convenience)
                    const directPosition = parseInt(action);
                    if (!isNaN(directPosition) && directPosition >= 1 && directPosition <= 9) {
                        // Treat as a move command
                        const directMoveResult = ticTacToeGame.makeMove(chatId, senderId, directPosition);
                        
                        if (directMoveResult.error) {
                            await message.reply(`❌ ${directMoveResult.error === 'no_active_game' ? 
                                'No active game found.' : 
                                'Invalid move or not your turn.'}`);
                            return { success: false };
                        }

                        // Same logic as 'move' case above
                        const game = directMoveResult.game;
                        const boardDisplay = ticTacToeGame.formatBoard(game.board);
                        
                        if (game.status === 'finished') {
                            await message.reply(`🎉 *Game Over!*\n\n${boardDisplay}\n\n🏆 Winner: ${game.winner.name} (${game.winner.symbol})`);
                            ticTacToeGame.endGame(chatId);
                        } else if (game.status === 'draw') {
                            await message.reply(`🤝 *It's a Draw!*\n\n${boardDisplay}`);
                            ticTacToeGame.endGame(chatId);
                        } else {
                            const currentPlayerObj = game.currentPlayer === 1 ? game.player1 : game.player2;
                            await message.reply(`✅ Move played!\n\n${boardDisplay}\n\n🎯 ${currentPlayerObj.name}'s turn (${currentPlayerObj.symbol})`);
                        }
                    } else {
                        await message.reply(`❌ Unknown action: ${action}\n\nUse \`${config.bot.commandPrefix}tictactoe\` to see available commands.`);
                        return { success: false };
                    }
                    break;
            }

            return { success: true };
            
        } catch (error) {
            console.error('Error in tictactoe command:', error);
            await message.reply('❌ Error in Tic-tac-toe game. Please try again.');
            return { success: false, error: error.message };
        }
    }
};