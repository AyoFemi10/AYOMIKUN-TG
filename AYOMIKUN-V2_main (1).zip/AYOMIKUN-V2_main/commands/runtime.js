const config = require('../config/settings');
const os = require('os');

module.exports = {
    name: 'runtime',
    description: 'Display bot runtime information and system stats',
    usage: '.runtime',
    
    async execute(message, whatsappService) {
        try {
            const chat = await message.getChat();
            const startTime = process.uptime();
            
            // Calculate uptime
            const days = Math.floor(startTime / 86400);
            const hours = Math.floor((startTime % 86400) / 3600);
            const minutes = Math.floor((startTime % 3600) / 60);
            const seconds = Math.floor(startTime % 60);
            
            // Memory usage
            const memUsage = process.memoryUsage();
            const totalMem = os.totalmem();
            const freeMem = os.freemem();
            const usedMem = totalMem - freeMem;
            
            // CPU info
            const cpus = os.cpus();
            const platform = os.platform();
            const arch = os.arch();
            
            // Bot info
            const nodeVersion = process.version;
            const botVersion = require('../package.json').version || '2.0.0';
            
            // Format bytes
            const formatBytes = (bytes) => {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
            };
            
            // Get WhatsApp connection state
            const connectionState = whatsappService.getConnectionState();
            
            const runtimeText = `🤖 *${config.bot.name} - Runtime Information*\n\n` +
                              
                              `⏱️ *Uptime:*\n` +
                              `${days}d ${hours}h ${minutes}m ${seconds}s\n\n` +
                              
                              `📊 *System Information:*\n` +
                              `• Platform: ${platform} (${arch})\n` +
                              `• Node.js: ${nodeVersion}\n` +
                              `• Bot Version: v${botVersion}\n` +
                              `• CPU Cores: ${cpus.length}\n` +
                              `• CPU Model: ${cpus[0]?.model || 'Unknown'}\n\n` +
                              
                              `💾 *Memory Usage:*\n` +
                              `• Bot Memory: ${formatBytes(memUsage.rss)}\n` +
                              `• Heap Used: ${formatBytes(memUsage.heapUsed)}\n` +
                              `• Heap Total: ${formatBytes(memUsage.heapTotal)}\n` +
                              `• System Used: ${formatBytes(usedMem)} / ${formatBytes(totalMem)}\n` +
                              `• System Free: ${formatBytes(freeMem)}\n\n` +
                              
                              `📱 *WhatsApp Status:*\n` +
                              `• Connection: ${connectionState}\n` +
                              `• Session: Active\n` +
                              `• Commands Loaded: ${Object.keys(require('../utils/commandParser').getAllCommands()).length}\n\n` +
                              
                              `⚙️ *Bot Configuration:*\n` +
                              `• Command Prefix: ${config.bot.commandPrefix}\n` +
                              `• Owner: ${config.bot.owner}\n` +
                              `• Payment: ${config.payment.enabled ? 'Enabled' : 'Disabled'}\n` +
                              `• Max Group Size: ${config.limits.maxGroupSize}\n` +
                              `• Cooldown: ${config.limits.commandCooldown}s\n\n` +
                              
                              `🔧 *Performance:*\n` +
                              `• Load Average: ${os.loadavg().map(load => load.toFixed(2)).join(', ')}\n` +
                              `• Event Loop Lag: ${process.hrtime.bigint() ? 'Normal' : 'Unknown'}\n\n` +
                              
                              `📈 *Statistics:*\n` +
                              `• Process ID: ${process.pid}\n` +
                              `• Started: ${new Date(Date.now() - startTime * 1000).toLocaleString()}\n` +
                              `• Timezone: ${Intl.DateTimeFormat().resolvedOptions().timeZone}\n\n` +
                              
                              `🎯 *Quick Commands:*\n` +
                              `• ${config.bot.commandPrefix}ping - Test bot response\n` +
                              `• ${config.bot.commandPrefix}menu - Show all commands\n` +
                              `• ${config.bot.commandPrefix}games - Gaming menu\n` +
                              `• ${config.bot.commandPrefix}session - Session management\n\n` +
                              
                              `💡 *Developer: ${config.bot.developer}*\n` +
                              `📞 Contact: ${config.bot.contact}`;

            await message.reply(runtimeText);
            return { success: true };
            
        } catch (error) {
            console.error('Error in runtime command:', error);
            await message.reply('❌ Error getting runtime information. Please try again.');
            return { success: false, error: error.message };
        }
    }
};